// EVENT LISTENER BUSCADOR
const buscador = document.getElementById("buscador")
document.querySelector(".search").addEventListener("submit", e => {
    e.preventDefault();

    buscadorFuncion()
})
document.getElementById("search").addEventListener("click", e => {
    e.preventDefault();

    buscadorFuncion()
})
function buscadorFuncion() {
    let txt = buscador.value

    if (txt != "" && txt != " ") {
        localStorage.setItem("buscador", txt)
        window.open("/Buscador/buscar.html", "_self")
    }
}